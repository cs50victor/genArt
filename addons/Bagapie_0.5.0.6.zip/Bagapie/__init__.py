# Blender Adoon BagaPie Modifier
# Created by Antoine Bagattini

#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.

#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.

#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <http://www.gnu.org/licenses/>.


# _______________________________________________ HELLO !

# This addon is free, you can use it for any purpose, modify it and share it.

# Special thanks to Franck Demongin which greatly contributed to this addon.

# Also thanks to all the people who support the development of this addon.
# Thanks to Sybren A. Stüvel (Scripting for artist on Blender Cloud), Drarkfall (Youtube).

# I'm not a programmer, just a newbie to Python. This code is not very good but it works.
# If you have any idea/advice to improve this addon, do not hesitate to contact me !

# _______________________________________________ USER INTERFACE / OP PANEL AND N PANEL

bl_info = {
    "name": "BagaPie Modifier",
    "author": "Antoine Bagattini",
    "version": (0, 5, 0, 6),
    "description": "Create a pie menu to add some modifier and Geometry Nodes preset.",
    "blender": (3, 0, 0),
    "cathegory": "3D view",
    "location": "Pie Menue, shortcut : J"
}

import bpy
from bpy.types import Menu, Operator, Panel

from . bagapie_ui import (
    BAGAPIE_MT_pie_menu,
    BAGAPIE_PT_modifier_panel, 
    MY_UL_List,
    BAGAPIE_OP_modifierDisplay,
    BAGAPIE_OP_modifierDisplayRender,
    BAGAPIE_OP_modifierApply,
)
from . bagapie_ui_op import ( 
    SwitchMode,
    EditMode,
    UseSolidify,
    InvertPaint,
    CleanWPaint,
    InvertWeight
)
from . bagapie_boolean_op import BAGAPIE_OT_boolean, BAGAPIE_OT_boolean_remove
from . bagapie_wall_op import BAGAPIE_OT_wall_remove, BAGAPIE_OT_wall
from . bagapie_array_op import BAGAPIE_OT_array_remove, BAGAPIE_OT_array, BAGAPIE_OT_drawarray
from . bagapie_scatter_op import BAGAPIE_OT_scatter_remove, BAGAPIE_OT_scatter
from . bagapie_scatterpaint_op import BAGAPIE_OT_scatterpaint_remove, BAGAPIE_OT_scatterpaint
from . bagapie_displace_op import BAGAPIE_OT_displace_remove, BAGAPIE_OT_displace
from . bagapie_curvearray_op import BAGAPIE_OT_curvearray_remove, BAGAPIE_OT_curvearray
from . bagapie_window_op import BAGAPIE_OT_window_remove, BAGAPIE_OT_window
from . bagapie_group_op import BAGAPIE_OT_ungroup, BAGAPIE_OT_group, BAGAPIE_OT_editgroup, BAGAPIE_OT_lockgroup, BAGAPIE_OT_duplicategroup, BAGAPIE_OT_duplicatelinkedgroup, BAGAPIE_OT_deletegroup
from . bagapie_instance_op import BAGAPIE_OT_makereal, BAGAPIE_OT_instance
from . bagapie_pointeffector_op import BAGAPIE_OT_pointeffector_remove, BAGAPIE_OT_pointeffector
from . bagapie_import_op import BAGAPIE_OT_importnodes
from . bagapie_proxy_op import BAGAPIE_OT_proxy, BAGAPIE_OT_proxy_remove
from . bagapie_wallbrick_op import BAGAPIE_OT_wallbrick, BAGAPIE_OT_wallbrick_remove
from . bagapie_ivy_op import BAGAPIE_OT_ivy, BAGAPIE_OT_ivy_remove, BAGAPIE_OT_AddVertOBJ, BAGAPIE_OT_AddObjectTarget, BAGAPIE_OT_RemoveObjectTarget
from . bagapie_pointsnapinstance import BAGAPIE_OT_pointsnapinstance, BAGAPIE_OT_pointsnapinstance_remove
from . bagapie_instancesdisplace_op import BAGAPIE_OT_instancesdisplace, BAGAPIE_OT_instancesdisplace_remove

# _______________________________________________ REGISTER / UNREGISTER

class BagapieSettings(bpy.types.PropertyGroup):
    val: bpy.props.StringProperty()

class bagapie_Preferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager

        # layout.prop(wm, "preview_dir")
        # layout.operator('bagapieassets.updatepath',text = 'Update Path' )
        layout.scale_y = 1.5
        layout.operator("wm.url_open", text="Get BagaPie Assets ! (Out beginning of december)", icon = 'FUND').url = "https://abaga.gumroad.com/l/BbGVh"
        layout.operator("wm.url_open", text="BagaPie Documentation", icon = 'TEXT').url = "https://www.f12studio.fr/bagapie"
        # layout.operator("wm.url_open", text="BagaPie Tutorial (Soon)", icon = 'PLAY').url = "https://www.youtube.com/channel/UC6_P9fMppVqOfDeDMGGBicA"
        layout.operator("wm.url_open", text="Help or sharing your creation with BagaPie on Discord", icon = 'COMMUNITY').url = "https://discord.gg/YtagqdPW6G"
        layout.operator("wm.url_open", text="Help or sharing your creation with BagaPie on BlenderArtists", icon = 'COMMUNITY').url = "https://blenderartists.org/t/bagapie-modifier-free-addon/1310959"
        layout.operator("wm.url_open", text="Demo File avilable on Gumroad", icon = 'BLENDER').url = "https://abaga.gumroad.com/l/BbGVh"
        layout.operator("wm.url_open", text="Join the Blender Development Fund !", icon = 'FUND').url = "https://fund.blender.org/"

bpy.utils.register_class(BagapieSettings)

addon_keymaps = []
addon_keymaps_group = []
addon_keymaps_grouplink = []
classes = [
    bagapie_Preferences,
    BAGAPIE_MT_pie_menu,
    BAGAPIE_PT_modifier_panel,
    MY_UL_List,
    SwitchMode,
    EditMode,
    UseSolidify,
    InvertPaint,
    CleanWPaint,
    InvertWeight,
    BAGAPIE_OT_wall_remove,
    BAGAPIE_OT_array_remove,
    BAGAPIE_OT_scatter_remove,
    BAGAPIE_OT_scatterpaint_remove,
    BAGAPIE_OT_displace_remove,
    BAGAPIE_OT_curvearray_remove,
    BAGAPIE_OT_window_remove,
    BAGAPIE_OT_ungroup,
    BAGAPIE_OT_makereal,
    BAGAPIE_OT_pointeffector_remove,
    BAGAPIE_OT_boolean,
    BAGAPIE_OT_boolean_remove,
    BAGAPIE_OT_wall,
    BAGAPIE_OT_array,
    BAGAPIE_OT_drawarray,
    BAGAPIE_OT_scatter,
    BAGAPIE_OT_scatterpaint,
    BAGAPIE_OT_displace,
    BAGAPIE_OT_curvearray,
    BAGAPIE_OT_window,
    BAGAPIE_OT_group,
    BAGAPIE_OT_editgroup,
    BAGAPIE_OT_lockgroup,
    BAGAPIE_OT_duplicategroup,
    BAGAPIE_OT_duplicatelinkedgroup,
    BAGAPIE_OT_deletegroup,
    BAGAPIE_OP_modifierDisplay,
    BAGAPIE_OP_modifierDisplayRender,
    BAGAPIE_OP_modifierApply,
    BAGAPIE_OT_instance,
    BAGAPIE_OT_pointeffector,
    BAGAPIE_OT_importnodes,
    BAGAPIE_OT_proxy_remove,
    BAGAPIE_OT_proxy,
    BAGAPIE_OT_wallbrick,
    BAGAPIE_OT_wallbrick_remove,
    BAGAPIE_OT_ivy,
    BAGAPIE_OT_ivy_remove,
    BAGAPIE_OT_AddObjectTarget,
    BAGAPIE_OT_RemoveObjectTarget,
    BAGAPIE_OT_AddVertOBJ,
    BAGAPIE_OT_pointsnapinstance,
    BAGAPIE_OT_pointsnapinstance_remove,
    BAGAPIE_OT_instancesdisplace,
    BAGAPIE_OT_instancesdisplace_remove,
    ]
    
def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
        kmi = km.keymap_items.new("wm.call_menu_pie", type='J', value='PRESS')
        kmi.properties.name = "BAGAPIE_MT_pie_menu"
        addon_keymaps.append((km,kmi))
        # Group Shortcut
        # Duplicate
        dupli = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
        dupli_id = km.keymap_items.new("bagapie.duplicategroup", type='J', alt=True, value='PRESS')
        addon_keymaps_group.append((dupli,dupli_id))
        # Duplicate linked
        dupli_link = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
        dupli_id_link = km.keymap_items.new("bagapie.duplicatelinkedgroup", type='N', alt=True, value='PRESS')
        addon_keymaps_grouplink.append((dupli_link,dupli_id_link))

    bpy.types.Scene.bagapieValue = bpy.props.StringProperty(
        name="My List",
        default="none"
    )

    bpy.types.Object.bagapieList = bpy.props.CollectionProperty(type=BagapieSettings)
    bpy.types.Object.bagapieIndex = bpy.props.IntProperty(name="Index", default=0)

def unregister():
    for km,kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    for dupli,dupli_id in addon_keymaps_group:
        dupli.keymap_items.remove(dupli_id)
    for dupli_link,dupli_id_link in addon_keymaps_grouplink:
        dupli_link.keymap_items.remove(dupli_id_link)
    addon_keymaps.clear()

    for cls in classes:
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()