import bpy
import json
import os
import addon_utils
from bpy.types import Operator
from . presets import bagapieModifiers
import random

class BAGAPIE_OT_pointeffector_remove(Operator):
    """ Remove Bagapie Point Effector modifiers """
    bl_idname = "bagapie.pointeffector_remove"
    bl_label = 'Remove Bagapie Point Effector'

    @classmethod
    def poll(cls, context):
        o = context.object

        return (
            o is not None and 
            o.type == 'MESH'
        )
    
    index: bpy.props.IntProperty(default=0)
    
    def execute(self, context):
        
        obj = context.object
        val = json.loads(obj.bagapieList[self.index]['val'])
        modifiers = val['modifiers']
        scatter_modifier = obj.modifiers.get("BagaScatter")
        scatt_nde_group = scatter_modifier.node_group
        effector_nde_main = scatt_nde_group.nodes.get(modifiers[1])
        effector_coll = effector_nde_main.inputs[0].default_value

        # DELETE NODES
        link_input_node = None
        link_output_node = None
        
        # get in and out link for this effector
        try:
            link_input_node = effector_nde_main.inputs[4].links[0].from_node
        except:
            link_input_node = None
        link_output_node = effector_nde_main.outputs[0].links[0].to_node

        min_position = effector_nde_main.location[0]

        scatt_nde_group.nodes.remove(effector_nde_main)

        # remove obj from coll and coll
        for ob in effector_coll.objects:
            effector_coll.objects.unlink(ob) 
        bpy.data.collections.remove(effector_coll)
        
        # Actualise Node Position
        for node in scatt_nde_group.nodes:    
            if node.location[0] < min_position:
                node.location[0] += 200

        # RELINK EXISTENT NODES
        if link_input_node is not None:
            new_link = scatt_nde_group.links
            if link_output_node.label == "BagaPie_Scatter":
                new_link.new(link_input_node.outputs[0], link_output_node.inputs[21])
            else:
                new_link.new(link_input_node.outputs[0], link_output_node.inputs[4])

        # REMOVE FROM LIST
        context.object.bagapieList.remove(self.index)

        return {'FINISHED'}


class BAGAPIE_OT_pointeffector(Operator):
    """Creates walls from the edges of the selected object or from curves"""
    bl_idname = 'bagapie.pointeffector'
    bl_label = bagapieModifiers['pointeffector']['label']
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        o = context.object

        return (
            o is not None and 
            o.type == 'MESH'
        )

 #PROPERTY VISIBLE IN THE POPUP PANEL
    # distance_min: bpy.props.FloatProperty(
    #     name="Distance Min",
    #     description="Placement du mur vis à vis de son axe.",
    #     default=0,
    # )
    # distance_max: bpy.props.FloatProperty(
    #     name="Distance Max",
    #     description="Placement du mur vis à vis de son axe.",
    #     default=1,
    # )
    # scale_min: bpy.props.FloatProperty(
    #     name="Scale Min",
    #     description="Placement du mur vis à vis de son axe.",
    #     default=0,
    # )

 # EXECUTED SCRIPT
    def execute(self, context):

            # IF SCATTER MODIFIER IS PRESENT
            target = bpy.context.active_object
            if target.modifiers.get("BagaScatter"):

             # IF SCATTER NODES ARE PRESENT
                nodegroup = target.modifiers.get("BagaScatter").node_group
                scatt_nde_main = nodegroup.nodes.get("BagaPie_Scatter")
                if scatt_nde_main:

                    obj = bpy.context.selected_objects #Add objects to coll instance
                    obj.remove(target)
                    if not obj:
                        Warning("No valid effector selected.", "WARNING", 'ERROR') 
                        return {'FINISHED'}
                    
                    else:
                    # COLLECTION
                        # Create collection and check if the main "Baga Collection" does not already exist
                        if bpy.data.collections.get("BagaPie") is None:
                            main_coll = bpy.data.collections.new("BagaPie")
                            bpy.context.scene.collection.children.link(main_coll)
                            scatter_master_coll = bpy.data.collections.new("BagaPie_Scatter")
                            main_coll.children.link(scatter_master_coll)
                            effector_coll = bpy.data.collections.new("BagaPie_Effector_" + target.name)
                            scatter_master_coll.children.link(effector_coll)
                        # If the main collection Bagapie already exist
                        elif bpy.data.collections.get("BagaPie_Scatter") is None:
                            main_coll = bpy.data.collections["BagaPie"]
                            scatter_master_coll = bpy.data.collections.new("BagaPie_Scatter")
                            main_coll.children.link(scatter_master_coll)
                            effector_coll = bpy.data.collections.new("BagaPie_Effector_" + target.name)
                            scatter_master_coll.children.link(effector_coll)
                        # If the main collection Bagapie_Scatter already exist
                        else:
                            effector_coll = bpy.data.collections.new("BagaPie_Effector_" + target.name)
                            scatter_master_coll = bpy.data.collections["BagaPie_Scatter"]
                            scatter_master_coll.children.link(effector_coll)

                    
                        for ob in obj:
                            if ob.name not in effector_coll.objects:
                                effector_coll.objects.link(ob)
                            else:
                                print(ob.name, "is already in BagaPie_Instance_"+target.name)

                        # GET NODES AND COUNT
                        scatt_nde = nodegroup.nodes
                        effector_count_real = 0
                        effector_latest = scatt_nde_main

                        for node in scatt_nde:
                            # Count how many scatter/scatter paint/effector are present
                            if node.label == "BagaPie_Effector":
                                effector_count_real += 1
                                if effector_latest is None:
                                    effector_latest = node
                                else:
                                    if node.location[0] < effector_latest.location[0]:
                                        effector_latest = node

                        # ADD NODES
                        Import_Nodes(self,context,"BagaPie_Effector")
                        effector_nde_main = nodegroup.nodes.new(type='GeometryNodeGroup')
                        effector_nde_main.node_tree = bpy.data.node_groups['BagaPie_Effector']
                        effector_nde_main.name = "BagaPie_Effector"
                        effector_nde_main.label = "BagaPie_Effector"

                    # POSITION NODES
                        effector_nde_main.location = (scatt_nde_main.location[0]-200-(effector_count_real*200), -850)

                    # LINK NODES,UI & CONFIG
                        new_link = nodegroup.links

                        if effector_latest != scatt_nde_main:
                            new_link.new(effector_nde_main.outputs[0], effector_latest.inputs[4])

                        else:
                            new_link.new(effector_nde_main.outputs[0], scatt_nde_main.inputs[21])

                        
                        effector_nde_main.inputs[0].default_value = effector_coll

                    # CUSTOM PROPERTY
                        val = {
                            'name': 'pointeffector',
                            'modifiers':[
                                        "BagaScatter",              # MODIFIER NAME
                                        effector_nde_main.name,     # NODE NAME
                                        ]
                        }
                        item = target.bagapieList.add()
                        item.val = json.dumps(val)
                
                        target.bagapieIndex = len(target.bagapieList)-1

                        return {'FINISHED'}


###################################################################################
# DISPLAY WARNING MESSAGE
###################################################################################
def Warning(message = "", title = "Message Box", icon = 'INFO'):

    def draw(self, context):
        self.layout.label(text=message)

    bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)

###################################################################################
# MANAGE COLLECTION
###################################################################################
def Collection_Setup(self,context,target):
    # Create collection and check if the main "Baga Collection" does not already exist
    if bpy.data.collections.get("BagaPie") is None:
        main_coll = bpy.data.collections.new("BagaPie")
        bpy.context.scene.collection.children.link(main_coll)
        scatter_master_coll = bpy.data.collections.new("BagaPie_Scatter")
        main_coll.children.link(scatter_master_coll)
        scatt_coll = bpy.data.collections.new("BagaPie_Scatter_" + target.name)
        scatter_master_coll.children.link(scatt_coll)
    # If the main collection Bagapie already exist
    elif bpy.data.collections.get("BagaPie_Scatter") is None:
        main_coll = bpy.data.collections["BagaPie"]
        scatter_master_coll = bpy.data.collections.new("BagaPie_Scatter")
        main_coll.children.link(scatter_master_coll)
        scatt_coll = bpy.data.collections.new("BagaPie_Scatter_" + target.name)
        scatter_master_coll.children.link(scatt_coll)
    # If the main collection Bagapie_Scatter already exist
    else:
        scatt_coll = bpy.data.collections.new("BagaPie_Scatter_" + target.name)
        scatter_master_coll = bpy.data.collections["BagaPie_Scatter"]
        scatter_master_coll.children.link(scatt_coll)

    return scatt_coll

###################################################################################
# IMPORT NODE GROUP
###################################################################################
def Import_Nodes(self,context,nodes_name):

    for mod in addon_utils.modules():
        if mod.bl_info['name'] == "BagaPie Modifier":
            filepath = mod.__file__
            file_path = filepath.replace("__init__.py","BagaPie_Nodes.blend")
        else:
            pass
    inner_path = "NodeTree"
    # file_path = r"C:\Users\antoi\Desktop\BagaPie Archive\Dev\Bagapie\BagaPie_Nodes.blend"

    bpy.ops.wm.append(
        filepath=os.path.join(file_path, inner_path, nodes_name),
        directory=os.path.join(file_path, inner_path),
        filename=nodes_name
        )
    
    return {'FINISHED'}