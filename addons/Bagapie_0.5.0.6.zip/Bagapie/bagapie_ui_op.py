import bpy
import json
from bpy.types import Operator

# These classes are used to call some existing operator from the addon panel.
# Some of them are probably stupid and some of them makes sense.

class SwitchMode(Operator):
    """Edit the painting of the last instantiated object"""
    bl_idname = "switch.mode"
    bl_label = "Switch Object Mode"
    def execute(self, context):

        obj = context.object
        val = json.loads(obj.bagapieList[obj.bagapieIndex]['val'])
        modifiers = val['modifiers']
        scatt_vertex_grp = modifiers[3]

        vertex_group = obj.vertex_groups
        vertex_group.active_index = vertex_group[scatt_vertex_grp].index

        bpy.ops.paint.weight_paint_toggle()
        return {'FINISHED'}

class EditMode(Operator):
    """Switch Object Mode"""
    bl_idname = "bool.mode"
    bl_label = "Switch Object Mode"
    def execute(self, context):

        try:
            obj = context.object
            val = json.loads(obj.bagapieList[obj.bagapieIndex]['val'])
            type = val['name']
            modifiers = val['modifiers']

            if type == 'boolean':
                bpy.ops.object.select_all(action='DESELECT')
                bool_obj = bpy.data.objects[modifiers[5]]
                bpy.context.view_layer.objects.active = bool_obj
                if bpy.context.object.mode == 'OBJECT':
                    bpy.ops.object.editmode_toggle()
                    bpy.ops.wm.tool_set_by_id(name="builtin.primitive_cube_add")
                elif bpy.context.object.mode == 'EDIT':
                    bpy.ops.wm.tool_set_by_id(name="builtin.select_box")
                    bpy.ops.object.editmode_toggle()

            else:
                if bpy.context.object.mode == 'OBJECT':
                    bpy.ops.object.editmode_toggle()
                    bpy.ops.wm.tool_set_by_id(name="builtin.primitive_cube_add")
                elif bpy.context.object.mode == 'EDIT':
                    bpy.ops.wm.tool_set_by_id(name="builtin.select_box")
                    bpy.ops.object.editmode_toggle()

        except:
            if bpy.context.object.mode == 'OBJECT':
                    bpy.ops.object.editmode_toggle()
                    bpy.ops.wm.tool_set_by_id(name="builtin.primitive_cube_add")
            elif bpy.context.object.mode == 'EDIT':
                bpy.ops.wm.tool_set_by_id(name="builtin.select_box")
                bpy.ops.object.editmode_toggle()

        return {'FINISHED'}

class UseSolidify(Operator):
    """Enable/Disable Solidify Modifier"""
    bl_idname = "solidify.visibility"
    bl_label = "Switch Object Mode"
    def execute(self, context):

        obj = context.object
        val = json.loads(obj.bagapieList[obj.bagapieIndex]['val'])
        type = val['name']
        modifiers = val['modifiers']        
        
        solidify_modifier = bpy.data.objects[modifiers[5]].modifiers[modifiers[4]]

        if solidify_modifier.show_viewport == False:
            solidify_modifier.show_viewport=True
            solidify_modifier.show_render=True
            solidify_modifier.show_in_editmode=True
        else:
            solidify_modifier.show_viewport=False
            solidify_modifier.show_render=False
            solidify_modifier.show_in_editmode=False

        return {'FINISHED'}

class InvertPaint(Operator):
    """Invert paint brush influence"""
    bl_idname = "invert.paint"
    bl_label = "Invert Weight Paint"
    def execute(self, context):
        weight_value = bpy.context.scene.tool_settings.unified_paint_settings.weight
        bpy.context.scene.tool_settings.unified_paint_settings.weight = weight_value*(-1)+1
        return {'FINISHED'}

class InvertWeight(Operator):
    """Invert paint"""
    bl_idname = "invert.weight"
    bl_label = "Invert Weight Value"
    def execute(self, context):
        bpy.ops.object.vertex_group_invert()
        return {'FINISHED'}

class CleanWPaint(Operator):
    """Lift all the painting"""
    bl_idname = "clean.paint"
    bl_label = "Clean Weight Paint"
    def execute(self, context):
        bpy.ops.object.editmode_toggle()
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.object.vertex_group_remove_from(use_all_groups=False)
        bpy.ops.paint.weight_paint_toggle()
        if bpy.context.scene.tool_settings.unified_paint_settings.weight < 1:
            bpy.ops.invert.paint()
        return {'FINISHED'}