from typing import Text
import bpy
import json
import addon_utils
from bpy.types import Menu, Panel, UIList, Operator
from . presets import bagapieModifiers

class BAGAPIE_MT_pie_menu(Menu):
    bl_label = "BagaPie"
    bl_idname = "BAGAPIE_MT_pie_menu"

    def draw(self, context):
        layout = self.layout
        target = bpy.context.active_object

        # BAGAPIE ASSETS
        addon_name = 'BagaPieAssets'
        success = addon_utils.check(addon_name)
        if success[0]:
            bp_assets = True
        else:
            bp_assets = False

        pie = layout.menu_pie()


    # PIE UI FOR ARRAY
        col = pie.column()
        col.label(text = "Array", icon = "MOD_ARRAY")
        split = col.split(align = True)
        split.scale_y = 1.2
        split.scale_x = 1.4
        split.operator_enum("wm.array","array_type")
        if bp_assets:
            imp = col.operator("bagapieassets.callpieforimport", text="Draw Array Assets")
            imp.import_mode= 'DrawArray'

    # PIE UI FOR BOOLEAN
        col = pie.column()
        col.label(text = "Boolean", icon = "MOD_BOOLEAN")
        split = col.split(align = True)
        split.scale_y = 1.2
        split.scale_x = 1.2
        split.operator_enum("wm.boolean", "operation_type")
        col.label(text = "")

    # PIE UI FOR ARCHITECTURE
        col = pie.column(align = True)
        col.label(text = "Architecture", icon = "HOME")
        col.scale_y = 1.2
        col.operator('bagapie.wall')
        col.operator('bagapie.wallbrick')
        col.operator("bagapie.window")

    # PIE UI FOR SCATTER
        col = pie.column(align = True)
        col.label(text = "Scattering", icon = "OUTLINER_DATA_HAIR")
        col.scale_y = 1.2
        if bp_assets:
            row = col.row(align=True)
            row.operator("wm.scatter")
            imp = row.operator("bagapieassets.callpieforimport", text="Asset")
            imp.import_mode= 'Scatter'
            row = col.row(align=True)
            row.operator("wm.scatter_paint")
            imp = row.operator("bagapieassets.callpieforimport", text="Asset")
            imp.import_mode= 'ScatterPaint'
            row = col.row(align=True)
            row.operator("bagapie.pointsnapinstance")
            imp = row.operator("bagapieassets.callpieforimport", text="Asset")
            imp.import_mode= 'PointSnapInstance'
        else:
            col.operator("wm.scatter")
            col.operator("wm.scatter_paint")
            col.operator("bagapie.pointsnapinstance")
        # col.operator("bagapie.pointsnapinstance")
        col.operator("bagapie.ivy")
        col.separator(factor = 3)

    # PIE UI FOR DEFORM
        col = pie.column(align = True)
        col.label(text = "Deformation", icon = "MOD_DISPLACE")
        col.scale_y = 1.2
        col.operator("wm.displace")
        col.operator("bagapie.instancesdisplace")
        col.label(text = "")
        col.label(text = "")
        col.label(text = "")

    # PIE UI FOR CURVE
        col = pie.column(align = True)
        col.label(text = "Curves", icon = "MOD_CURVE")
        col.scale_y = 1.2
        if bp_assets:
            row = col.row(align=True)
            row.operator("wm.curvearray")
            imp = row.operator("bagapieassets.callpieforimport", text="Asset")
            imp.import_mode= 'CurveArray'
            col.label(text = "")
            col.label(text = "")
            col.label(text = "")
        else:
            col.operator("wm.curvearray")
            col.label(text = "")
            col.label(text = "")
            col.label(text = "")

    # PIE UI FOR MANAGE
        col = pie.column(align = True)
        col.label(text = "")
        col.label(text = "")
        col.label(text = "")
        col.label(text = "")
        col.label(text = "Manage", icon = "PACKAGE")
        col.scale_y = 1.2
        col.operator("bagapie.proxy")
        col.operator("bagapie.group")
        if bpy.context.object.type == 'EMPTY':
            col.operator("bagapie.makereal")
        try:
            prop = target["bagapie"]
        except:
            prop = None
        if prop is not None:
            if target["bagapie_child"][0].hide_select == True:
                col.operator("bagapie.editgroup")
            else:
                col.operator("bagapie.lockgroup")
            col.operator("bagapie.ungroup")
            col.operator("bagapie.instance")

    # PIE UI FOR EFFECTOR
        col = pie.column(align = True)
        col.label(text = "")
        col.label(text = "Effector", icon = "PARTICLES")
        col.scale_y = 1.2
        if target.modifiers.get("BagaScatter"):
            if target.modifiers.get("BagaScatter").node_group.nodes.get("BagaPie_Scatter"):
                col.operator("bagapie.pointeffector")
            else:
                col.label(text = "No Scatter available")
        else:
            col.label(text = "No Scatter available")


class MY_UL_List(UIList):
    """BagaPie UIList."""

    def draw_item(self, context, layout, data, item, icon, active_data,
                  active_propname, index):

        val = json.loads(item.val)
        name = val['name']
        label = bagapieModifiers[name]['label']
        icon = bagapieModifiers[name]['icon']

        obj = context.object
        modifiers = val['modifiers']

        # Make sure your code supports all 3 layout types
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.label(text=label, icon = icon)
            row = layout.row(align=True)

            mo_type = val['name']

            # List of modifier type to avoid dor apply/remove
            assets_type_list = ["stump","tree","grass","rock","plant"]
            avoid_list = ["scatter","scatterpaint","pointeffector","pointsnapinstance","instancesdisplace"]
            for a in assets_type_list:
                avoid_list.append(a)

            if mo_type not in avoid_list:
                row.operator("apply.modifier",text="", icon='CHECKMARK')

            if mo_type not in assets_type_list:
                row.operator('bagapie.'+ name +'_remove', text="", icon='REMOVE').index=index

            if mo_type == "scatter":

                scatter_modifier = obj.modifiers.get("BagaScatter")
                scatt_nde_group = scatter_modifier.node_group
                
                scatt_nde_visibility_op = obj.modifiers[modifiers[0]].node_group.nodes["BagaPie_Scatter"].inputs[22].default_value
                scatt_nde_visibility_bool = obj.modifiers[modifiers[0]].node_group.nodes["BagaPie_Scatter"].inputs[23].default_value

                if scatt_nde_visibility_op == False and scatt_nde_visibility_bool == True:
                    viewport_icon = 'RESTRICT_VIEW_ON'
                    render_icon = 'RESTRICT_RENDER_OFF'

                elif scatt_nde_visibility_op == True and scatt_nde_visibility_bool == True:
                    viewport_icon = 'RESTRICT_VIEW_OFF'
                    render_icon = 'RESTRICT_RENDER_OFF'

                elif scatt_nde_visibility_op == True and scatt_nde_visibility_bool == False:
                    viewport_icon = 'RESTRICT_VIEW_OFF'
                    render_icon = 'RESTRICT_RENDER_ON'

                elif scatt_nde_visibility_op == False and scatt_nde_visibility_bool == False:
                    viewport_icon = 'RESTRICT_VIEW_ON'
                    render_icon = 'RESTRICT_RENDER_ON'

            elif mo_type == "pointeffector":

                scatter_modifier = obj.modifiers.get("BagaScatter")
                scatt_nde_group = scatter_modifier.node_group
                
                scatt_nde_visibility_op = obj.modifiers[modifiers[0]].node_group.nodes[modifiers[1]].inputs[5].default_value
                scatt_nde_visibility_bool = obj.modifiers[modifiers[0]].node_group.nodes[modifiers[1]].inputs[6].default_value

                if scatt_nde_visibility_op == False and scatt_nde_visibility_bool == True:
                    viewport_icon = 'RESTRICT_VIEW_ON'
                    render_icon = 'RESTRICT_RENDER_OFF'

                elif scatt_nde_visibility_op == True and scatt_nde_visibility_bool == True:
                    viewport_icon = 'RESTRICT_VIEW_OFF'
                    render_icon = 'RESTRICT_RENDER_OFF'

                elif scatt_nde_visibility_op == True and scatt_nde_visibility_bool == False:
                    viewport_icon = 'RESTRICT_VIEW_OFF'
                    render_icon = 'RESTRICT_RENDER_ON'

                elif scatt_nde_visibility_op == False and scatt_nde_visibility_bool == False:
                    viewport_icon = 'RESTRICT_VIEW_ON'
                    render_icon = 'RESTRICT_RENDER_ON'

            elif mo_type == "scatterpaint":
                scatter_modifier = obj.modifiers.get("BagaScatter")
                scatt_nde_group = scatter_modifier.node_group
                
                scatt_nde_visibility_op = obj.modifiers[modifiers[0]].node_group.nodes[modifiers[1]].inputs[12].default_value
                scatt_nde_visibility_bool = obj.modifiers[modifiers[0]].node_group.nodes[modifiers[1]].inputs[13].default_value

                if scatt_nde_visibility_op == False and scatt_nde_visibility_bool == True:
                    viewport_icon = 'RESTRICT_VIEW_ON'
                    render_icon = 'RESTRICT_RENDER_OFF'

                elif scatt_nde_visibility_op == True and scatt_nde_visibility_bool == True:
                    viewport_icon = 'RESTRICT_VIEW_OFF'
                    render_icon = 'RESTRICT_RENDER_OFF'

                elif scatt_nde_visibility_op == True and scatt_nde_visibility_bool == False:
                    viewport_icon = 'RESTRICT_VIEW_OFF'
                    render_icon = 'RESTRICT_RENDER_ON'

                elif scatt_nde_visibility_op == False and scatt_nde_visibility_bool == False:
                    viewport_icon = 'RESTRICT_VIEW_ON'
                    render_icon = 'RESTRICT_RENDER_ON'

            elif mo_type == "wallbrick":
                if obj.type == 'MESH':
                    viewport_icon = 'RESTRICT_VIEW_OFF'
                    if obj.modifiers[modifiers[0]].show_viewport == False:
                        viewport_icon = 'RESTRICT_VIEW_ON'
                    render_icon = 'RESTRICT_RENDER_OFF'
                    if obj.modifiers[modifiers[0]].show_render == False:
                        render_icon = 'RESTRICT_RENDER_ON'
                else:
                    viewport_icon = 'RESTRICT_VIEW_OFF'
                    if obj.modifiers[modifiers[1]].show_viewport == False:
                        viewport_icon = 'RESTRICT_VIEW_ON'
                    render_icon = 'RESTRICT_RENDER_OFF'
                    if obj.modifiers[modifiers[1]].show_render == False:
                        render_icon = 'RESTRICT_RENDER_ON'

            elif mo_type not in assets_type_list:
                viewport_icon = 'RESTRICT_VIEW_OFF'
                if obj.modifiers[modifiers[0]].show_viewport == False:
                    viewport_icon = 'RESTRICT_VIEW_ON'
                render_icon = 'RESTRICT_RENDER_OFF'
                if obj.modifiers[modifiers[0]].show_render == False:
                    render_icon = 'RESTRICT_RENDER_ON'

            if mo_type not in assets_type_list:
                row.operator("hide.viewport",text="", icon=viewport_icon).index=index
                row.operator("hide.render",text="", icon=render_icon).index=index


        elif self.layout_type in {'GRID'}:
            pass


class BAGAPIE_PT_modifier_panel(Panel):
    bl_idname = 'BAGAPIE_PT_modifier_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BagaPie"
    bl_label = "BagaPie Modifier"

    
    @classmethod
    def poll(cls, context):
        o = context.object

        return (
            o is not None and 
            o.type == 'MESH' or 'CURVE'
        )
        
    def draw(self, context):
        layout = self.layout

        obj = context.object
        obj_allowed_types = ["MESH","CURVE","EMPTY"]

        if obj and obj.type in obj_allowed_types:
            col = layout.column()

            # col.label(text="Modifier List :")

            col.template_list("MY_UL_List", "The_List", obj,
                            "bagapieList", obj, "bagapieIndex")
            
            try:
                prop = obj["bagapie_child"]
            except:
                prop = None

            if obj.bagapieIndex < len(obj.bagapieList):


                val = json.loads(obj.bagapieList[obj.bagapieIndex]['val'])
                type = val['name']
                modifiers = val['modifiers']
            
                label = bagapieModifiers[type]['label']
                icon = bagapieModifiers[type]['icon']

                if type == "wall":
                    col.label(text="Modifier Properties :")
                    box = layout.box()
                    box.label(text=label, icon=icon)

                    box.prop(obj.modifiers[modifiers[1]], 'screw_offset', text="Wall Height")
                    box.prop(obj.modifiers[modifiers[2]], 'thickness', text="Wall Thickness")
                    box.prop(obj.modifiers[modifiers[2]], 'offset', text="Wall Axis Offset")
                
                elif type == "wallbrick":
                    col.label(text="Modifier Properties :")
                    box = layout.box()
                    box.label(text=label, icon=icon)

                    if obj.type == 'MESH':
                        index = 0
                    else:
                        index = 1
                    box = box.column(align=True)
                    box.prop(obj.modifiers[modifiers[index]], '["Input_2"]', text="Height")
                    box.prop(obj.modifiers[modifiers[index]], '["Input_3"]', text="Thickness")
                    box.prop(obj.modifiers[modifiers[index]], '["Input_4"]', text="Length")
                    box = layout.box()
                    box = box.column(align=False)
                    box.prop(obj.modifiers[modifiers[index]], '["Input_5"]', text="Row Count")
                    box = box.column(align=True)
                    box.prop(obj.modifiers[modifiers[index]], '["Input_6"]', text="Row Offset")
                    box.prop(obj.modifiers[modifiers[index]], '["Input_7"]', text="Horizontal Offset")
                    box.prop(obj.modifiers[modifiers[index]], '["Input_8"]', text="Flip")
                    
                    box = layout.box()
                    row = box.row()
                    row.label(text="Random")
                    box = box.column(align=True)
                    row = box.row()
                    row.label(text="Position Min / Max")
                    row = box.row()
                    row.prop(obj.modifiers[modifiers[index]], '["Input_9"]', text="")
                    row = box.row()
                    row.prop(obj.modifiers[modifiers[index]], '["Input_10"]', text="")
                    row = box.row()
                    row.label(text="Rotation Min / Max")
                    row = box.row()
                    row.prop(obj.modifiers[modifiers[index]], '["Input_11"]', text="")
                    row = box.row()
                    row.prop(obj.modifiers[modifiers[index]], '["Input_12"]', text="")
                    row = box.row()
                    row.label(text="Scale Min / Max")
                    row = box.row()
                    row.prop(obj.modifiers[modifiers[index]], '["Input_13"]', text="")
                    row = box.row()
                    row.prop(obj.modifiers[modifiers[index]], '["Input_14"]', text="")
                    
                    box = layout.box()
                    row = box.row()
                    row.label(text="Deformation")
                    box = box.column(align=True)
                    row = box.row()
                    row.prop(obj.modifiers[modifiers[index]], '["Input_15"]', text="")
                    row = box.row()
                    row.prop(obj.modifiers[modifiers[index]], '["Input_16"]', text="Scale")

                elif type == "array":
                    col.label(text="Modifier Properties :")
                    array_modifier = obj.modifiers[modifiers[0]]
                    array_type = modifiers[1]

                    if array_type == 'LINE':
                        col = layout.column(align=True)
                        col.prop(array_modifier, '["Input_4"]', text = "Count")
                        col.prop(array_modifier, '["Input_3"]', text = "Constant Offset")
                        col.prop(array_modifier, '["Input_5"]', text = "Relative Offset")

                        box = layout.box()
                        box.label(text="Random")
                        box.prop(array_modifier, '["Input_6"]', text = "Position")
                        box.prop(array_modifier, '["Input_7"]', text = "Rotation")
                        col = box.column(align=True)
                        col.prop(array_modifier, '["Input_8"]', text = "Scale")
                        box.prop(array_modifier, '["Input_9"]', text = "Seed")

                    if array_type == 'GRID':
                        col = layout.column(align=True)
                        col.prop(array_modifier, '["Input_2"]', text = "Count X")
                        col.prop(array_modifier, '["Input_9"]', text = "Count Y")
                        box = layout.box()
                        col = box.column(align=True)
                        col.prop(array_modifier, '["Input_3"]', text = "Constant Offset X")
                        col.prop(array_modifier, '["Input_11"]', text = "Constant Offset Y")
                        col = box.column(align=True)
                        col.prop(array_modifier, '["Input_4"]', text = "Relative Offset X")
                        col.prop(array_modifier, '["Input_10"]', text = "Relative Offset Y")
                        col = box.column(align=True)
                        col.prop(array_modifier, '["Input_12"]', text = "Midlevel X")
                        col.prop(array_modifier, '["Input_13"]', text = "Midlevel Y")

                        box = layout.box()
                        box.label(text="Random")
                        box.prop(array_modifier, '["Input_5"]', text = "Position")
                        box.prop(array_modifier, '["Input_6"]', text = "Rotation")
                        col = box.column(align=True)
                        col.prop(array_modifier, '["Input_8"]', text = "Scale")
                        box.prop(array_modifier, '["Input_7"]', text = "Seed")

                    if array_type == 'CIRCLE':
                        col = layout.column(align=True)
                        col.prop(array_modifier, '["Input_2"]', text = "Count")
                        col.prop(array_modifier, '["Input_3"]', text = "Ring Count")
                        col.prop(array_modifier, '["Input_19"]', text = "Use Constant Distance")
                        col = layout.column(align=True)
                        col.prop(array_modifier, '["Input_4"]', text = "Radius")
                        col.prop(array_modifier, '["Input_8"]', text = "Ring Offset")
                        col.prop(array_modifier, '["Input_9"]', text = "Ring Offset Z")
                        col.prop(array_modifier, '["Input_20"]', text = "Constant Distance")

                        col.prop(array_modifier, '["Input_14"]', text = "Rotation")
                        col.prop(array_modifier, '["Input_10"]', text = "Align to Center")

                        box = layout.box()
                        box.label(text="Random")
                        box.prop(array_modifier, '["Input_17"]', text = "Position")
                        box.prop(array_modifier, '["Input_15"]', text = "Rotation")
                        col = box.column(align=True)
                        col.prop(array_modifier, '["Input_16"]', text = "Scale")
                        box.prop(array_modifier, '["Input_18"]', text = "Seed")
                        
                    if array_type == 'CURVE':
                        col = layout.column(align=True)
                        col.prop(array_modifier, '["Input_2"]', text = "Target")
                        col.label(text="Set target in Modifier Prop")
                        col.prop(array_modifier, '["Input_5"]', text = "Length")
                        # col.prop(array_modifier["Input_4"], 'default_value', text="Use Count")
                        col.prop(array_modifier, '["Input_4"]', text = "Use Count")
                        col.prop(array_modifier, '["Input_6"]', text = "Count")
                        col = layout.column(align=True)
                        col.prop(array_modifier, '["Input_3"]', text = "Rotation")
                        col.prop(array_modifier, '["Input_14"]', text = "Scale")
                        box = layout.box()
                        box.label(text="Random")
                        box.prop(array_modifier, '["Input_7"]', text = "Random Position")
                        box.prop(array_modifier, '["Input_8"]', text = "Random Rotation")
                        box.prop(array_modifier, '["Input_9"]', text = "Random Scale")
                        box.prop(array_modifier, '["Input_12"]', text = "Seed")

                        box = layout.box()
                        box.prop(array_modifier, '["Input_10"]', text = "Align to Vector")
                        box = box.row(align=True)
                        box.prop(array_modifier, '["Input_11"]', text = "Vector")
        
                elif type == "scatter":
                    col.label(text="Modifier Properties :")
                    scatter_modifier = obj.modifiers[modifiers[0]].node_group.nodes["BagaPie_Scatter"]
                    
                    col = layout.column(align=True)
                    col.scale_y = 1.2
                    col.prop(scatter_modifier.inputs[2], 'default_value', text = "Distance Min")
                    col.prop(scatter_modifier.inputs[3], 'default_value', text = "Density Max")
                    col.prop(scatter_modifier.inputs[4], 'default_value', text = "% Viewport Display")
                    col.prop(scatter_modifier.inputs[5], 'default_value', text = "Align Z")
                    col.prop(scatter_modifier.inputs[6], 'default_value', text = "Seed")

                    box = layout.box()
                    box = box.column(align=True)
                    row = box.row()
                    row.label(text="Position")
                    row = box.row()
                    row.prop(scatter_modifier.inputs[7], 'default_value', text = "")
                    row = box.row()
                    row.label(text="Rotation")
                    box = box.column(align=False)
                    row = box.row()
                    row.prop(scatter_modifier.inputs[8], 'default_value', text = "")
                    row = box.row()
                    row = box.column(align=True)
                    row.prop(scatter_modifier.inputs[9], 'default_value', text = "Scale Min")
                    row.prop(scatter_modifier.inputs[10], 'default_value', text = "Scale Max")

                    box = layout.box()
                    row = box.row()
                    row.label(text="Random")
                    box = box.column(align=True)
                    row = box.row()
                    row.label(text="Position Min / Max")
                    row = box.row()
                    row.prop(scatter_modifier.inputs[11], 'default_value', text = "")
                    row = box.row()
                    row.prop(scatter_modifier.inputs[12], 'default_value', text = "")
                    row = box.row()
                    row.label(text="Rotation Min / Max")
                    row = box.row()
                    row.prop(scatter_modifier.inputs[13], 'default_value', text = "")
                    row = box.row()
                    row.prop(scatter_modifier.inputs[14], 'default_value', text = "")
                    row = box.row()
                    row.label(text="Scale Min / Max")
                    row = box.row()
                    row.prop(scatter_modifier.inputs[15], 'default_value', text = "")
                    row = box.row()
                    row.prop(scatter_modifier.inputs[16], 'default_value', text = "")

                    box = layout.box()
                    box.label(text="Scattering Texture")
                    row = box.column(align=True)
                    row.prop(scatter_modifier.inputs[17], 'default_value', text = "Fac")
                    row.prop(scatter_modifier.inputs[18], 'default_value', text = "Scale")
                    row.prop(scatter_modifier.inputs[19], 'default_value', text = "Offset")
                    row.prop(scatter_modifier.inputs[20], 'default_value', text = "Smooth")

                elif type == "displace":
                    col.label(text="Modifier Properties :")
                    displace_subdiv = obj.modifiers[modifiers[0]]
                    displace_disp = obj.modifiers[modifiers[1]]
                    texture = bpy.data.textures[modifiers[2]]

                    box = layout.box()# SUBDIVISION
                    box.label(text="Subdivision")
                    box.prop(displace_subdiv, 'subdivision_type', text="Type")
                    box = box.column(align=True)
                    box.prop(displace_subdiv, 'levels', text="Subdivision")
                    box.prop(displace_subdiv, 'render_levels', text="Subdivision Render")

                    box = layout.box()# DISPLACEMENT
                    box.label(text="Displace")
                    box.prop(displace_disp, 'direction', text="Direction")
                    box = box.column(align=True)
                    box.prop(displace_disp, 'strength', text="Strength")
                    box.prop(displace_disp, 'mid_level', text="Midlevel")
                    box = layout.box()

                    box.label(text="Texture")# TEXTURE
                    box.prop(texture, 'type', text="Type")
                    if texture.type == 'IMAGE':
                        box.label(text="Go in Texture tab.")
                    box.prop(displace_disp, 'texture_coords', text="Mapping")
                    if displace_disp.texture_coords == 'OBJECT':
                        box.prop(displace_disp, 'texture_coords_object', text="Object")
                    box = box.column(align=True)
                    box.prop(texture, 'noise_scale', text="Scale")
                    box.prop(texture, 'intensity', text="Brightness")
                    box.prop(texture.color_ramp.elements[0], 'position', text="Ramp Min")
                    box.prop(texture.color_ramp.elements[1], 'position', text="Ramp Max")

                elif type == "scatterpaint":
                    col.label(text="Modifier Properties :")

                    col = layout.column(align=True)
                    col.scale_y = 2.0

                    if bpy.context.object.mode == 'OBJECT':
                        col.operator("switch.mode", text= "Paint !")

                    if bpy.context.object.mode == 'WEIGHT_PAINT':
                        if bpy.context.scene.tool_settings.unified_paint_settings.weight < 1:
                            col.operator("invert.paint", text="ADD")
                        else:
                            col.operator("invert.paint", text="REMOVE")

                        col.scale_y = 1
                        col.operator("clean.paint", text= "CLEAN PAINT")
                        col.operator("invert.weight", text= "INVERT PAINT")

                        col = layout.column()
                        col.scale_y = 2
                        col.operator("switch.mode", text="EXIT !")

                    scatter_modifier = obj.modifiers.get("BagaScatter")
                    scatt_nde_group = scatter_modifier.node_group
                    scatterpaint_count = int(modifiers[2])
                    scatt_nde_main = scatt_nde_group.nodes.get(modifiers[1])

                    col = layout.column(align=True)
                    col.scale_y = 1.2
                    col.prop(scatt_nde_main.inputs[1], 'default_value', text = "Source Collection")
                    col.prop(scatt_nde_main.inputs[2], 'default_value', text = "Distance Min")
                    col.prop(scatt_nde_main.inputs[3], 'default_value', text = "Density")
                    col.prop(scatt_nde_main.inputs[4], 'default_value', text = "% Viewport Display")


                    box = layout.box()
                    box = box.column(align=True)
                    box.prop(scatt_nde_main.inputs[7], 'default_value', text = "Random Position")
                    box.prop(scatt_nde_main.inputs[8], 'default_value', text = "Random Rotation")
                    box.prop(scatt_nde_main.inputs[11], 'default_value', text = "Align Z")
                    box.prop(scatt_nde_main.inputs[9], 'default_value', text = "Scale Min")
                    box.prop(scatt_nde_main.inputs[10], 'default_value', text = "Scale Max")
                    box.prop(scatt_nde_main.inputs[5], 'default_value', text = "Seed")

                    box.label(text="Current Layer :")
                    box.prop(obj.vertex_groups, 'active_index', text = obj.vertex_groups.active.name)

                elif type == "curvearray":
                    col.label(text="Modifier Properties :")
                    arraycurve_array = obj.modifiers[modifiers[0]]
                    arraycurve_curve = obj.modifiers[modifiers[1]]

                    col = layout.column()
                    col.prop(arraycurve_curve, 'deform_axis', text="Axis")
                    box = layout.box()
                    box.prop(arraycurve_array, 'use_relative_offset', text="Use Relative Offset")
                    box.prop(arraycurve_array, 'relative_offset_displace', text="Ralative Offset")
                    box = layout.box()
                    box.prop(arraycurve_array, 'use_constant_offset', text="Use Constant Offset")
                    box.prop(arraycurve_array, 'constant_offset_displace', text="Constant Offset")

                elif type == "window":
                    col.label(text="Modifier Properties :")

                    if modifiers[6] == "win":
                        window_weld = obj.modifiers[modifiers[0]]
                        window_disp = obj.modifiers[modifiers[1]]
                        window_wire = obj.modifiers[modifiers[2]]
                        window_bevel = obj.modifiers[modifiers[3]]

                        box = layout.box()
                        box.prop(window_disp, 'strength', text="Offset")
                        box.prop(window_wire, 'thickness', text="Window Size")
                        box.prop(window_wire, 'offset', text="Window Offset")
                        box.prop(window_bevel, 'width', text="Window Bevel")
                        box.prop(window_weld, 'merge_threshold', text="Merge by Distance")


                        col = layout.column()
                        col.scale_y = 1.5
                        active_ob = bpy.context.active_object
                        if bpy.context.object.mode == 'OBJECT' and active_ob == obj:
                            col.operator("bool.mode", text= "More Window !")
                        elif bpy.context.object.mode == 'EDIT' and active_ob == obj:
                            col.operator("bool.mode", text= "EXIT")
                        else:
                            col.label(text="Selects the bounding box of the window")
                        col = layout.column()

                        col = layout.column(align=True)
                        col.separator(factor = 3)


                        # lines_y = 5
                        # lines_x = 5
                        # col.prop(bpy.context.scene.bpa_prop, 'asset_import_mode', text="Linked", toggle = True)
                        # col.prop(bpy.context.scene.bpa_prop, 'asset_import_mode', text="Append", toggle = True, invert_checkbox = True)
                        

                        # for line in range(lines_y):
                        #     row = col.row(align = True)
                        #     row.scale_y = 2.5
                        #     row.operator("bool.mode", text= "")
                        #     for line in range(lines_x):
                        #         row.scale_x = 0.05
                        #         row.operator("bool.mode", text= "")
                        #         row.scale_x = 1
                        #         row.operator("bool.mode", text= "")
                        
                        #     if line < lines_y-1:
                        #         row = col.row(align = True)
                        #         row.scale_y = 0.4
                        #         row.operator("bool.mode", text= "")
                        #         for line in range(lines_x):
                        #             row.scale_x = 0.05
                        #             row.operator("bool.mode", text= "")
                        #             row.scale_x = 1
                        #             row.operator("bool.mode", text= "")






                        # row = col.row(align = True)
                        # row.operator("bool.mode", text= "")
                        # row.scale_x = 0.05
                        # row.operator("bool.mode", text= "")
                        # row.scale_x = 1
                        # row.operator("bool.mode", text= "")
                        # row.scale_x = 0.05
                        # row.operator("bool.mode", text= "")
                        # row.scale_x = 1
                        # row.operator("bool.mode", text= "")
                        
                        # row = col.row(align = True)
                        # row.scale_y = 0.4
                        # row.operator("bool.mode", text= "")
                        # row.scale_x = 0.05
                        # row.operator("bool.mode", text= "")
                        # row.scale_x = 1
                        # row.operator("bool.mode", text= "")
                        # row.scale_x = 0.05
                        # row.operator("bool.mode", text= "")
                        # row.scale_x = 1
                        # row.operator("bool.mode", text= "")

                        # row = col.row(align = True)
                        # row.operator("bool.mode", text= "")
                        # row.scale_x = 0.05
                        # row.operator("bool.mode", text= "")
                        # row.scale_x = 1
                        # row.operator("bool.mode", text= "")
                        # row.scale_x = 0.05
                        # row.operator("bool.mode", text= "")
                        # row.scale_x = 1
                        # row.operator("bool.mode", text= "")





                    elif modifiers[6] == "wall":

                        window = bpy.data.objects[modifiers[7]]

                        window_weld = window.modifiers[modifiers[1]]
                        window_disp = window.modifiers[modifiers[2]]
                        window_wire = window.modifiers[modifiers[3]]
                        window_bevel = window.modifiers[modifiers[4]]

                        box = layout.box()
                        box.prop(window_disp, 'strength', text="Offset")
                        box.prop(window_wire, 'thickness', text="Window Size")
                        box.prop(window_wire, 'offset', text="Window Offset")
                        box.prop(window_bevel, 'width', text="Window Bevel")
                        box.prop(window_weld, 'merge_threshold', text="Merge by Distance")
                        

                elif type == "pointeffector":
                    col.label(text="Modifier Properties :")
                    effector_modifier = obj.modifiers[modifiers[0]]
                    effector_nde = effector_modifier.node_group.nodes.get(modifiers[1])

                    col = layout.column(align=True)
                    col.scale_y = 1.2
                    col.prop(effector_nde.inputs[1], 'default_value', text = "Distance Min")
                    col.prop(effector_nde.inputs[2], 'default_value', text = "Distance Max")
                    col.prop(effector_nde.inputs[3], 'default_value', text = "Density")

                elif type == "boolean":
                    col.label(text="Modifier Properties :")
                    box = layout.box()

                    box.label(text="Boolean Type")
                    box.prop(obj.modifiers[modifiers[0]], 'operation', text="")
                    box.prop(obj.modifiers[modifiers[0]], 'solver', text="")
                    if obj.modifiers[modifiers[0]].solver == 'EXACT':
                        box = box.row(align = True)
                        box.prop(obj.modifiers[modifiers[0]], 'use_self', text="Use self")
                        box.prop(obj.modifiers[modifiers[0]], 'use_hole_tolerant', text="Hole Tolerant")

                    box = layout.box()
                    box.label(text="Boolean Target")
                    box = box.column(align = True)
                    box.prop(obj.modifiers[modifiers[1]], 'segments', text="Bevel Segments")
                    box.prop(obj.modifiers[modifiers[1]], 'width', text="Bevel Size")

                    bool_obj = bpy.data.objects[modifiers[5]]

                    box = layout.box()
                    box.label(text="Boolean Object")
                    box = box.column(align = True)
                    box.prop(bool_obj.modifiers[modifiers[3]], 'segments', text="Bevel Segments")
                    box.prop(bool_obj.modifiers[modifiers[3]], 'width', text="Bevel Size")
                    box.prop(bool_obj.modifiers[modifiers[6]], 'strength', text="Displace")

                    box = box.column(align = False)
                    col = box.column()
                    if bool_obj.modifiers[modifiers[4]].show_render == False:
                        box.operator("solidify.visibility", text= "Use Solidify")
                    else:
                        box.operator("solidify.visibility", text= "Disable Solidify")
                    box = box.column(align = True)  
                    box.prop(bool_obj.modifiers[modifiers[4]], 'thickness', text="Solidify")
                    box.prop(bool_obj.modifiers[modifiers[4]], 'offset', text="Solidify Offset")
                    box = box.row(align = True)
                    box.label(text="Mirror XYZ")
                    box.prop(bool_obj.modifiers[modifiers[2]], 'use_axis', text="")
                    
                    col = layout.column()
                    col.scale_y = 2.0
                    active_ob = bpy.context.active_object
                    if bpy.context.object.mode == 'OBJECT' and active_ob == obj:
                        col.operator("bool.mode", text= "More Boolean !")
                    elif bpy.context.object.mode == 'EDIT' and active_ob == obj:
                        col.operator("bool.mode", text= "EXIT")
                
                elif type == "ivy":
                    col.label(text="Modifier Properties :")
                    ivy_modifier = obj.modifiers[modifiers[0]]
                    box = layout.box()
                    box = box.column(align=True)
                    box.scale_y = 1.5
                    box.operator("bagapie.addvertcursor", text="Add Ivy to 3D Cursor")
                    row=box.row(align=True)
                    row.operator("bagapie.addobjecttarget", text="Target", icon = 'ADD')
                    row.operator("bagapie.removeobjecttarget", text="Target", icon = 'REMOVE')
                    box = layout.box()

                    box.label(text="Ivy")
                    box = box.column(align=True)
                    box.prop(ivy_modifier, '["Input_3"]', text = "Radius")
                    box.prop(ivy_modifier, '["Input_5"]', text = "Height")
                    box.prop(ivy_modifier, '["Input_6"]', text = "Loop")
                    box.prop(ivy_modifier, '["Input_2"]', text = "Resolution")

                    box = layout.box()
                    box = box.column(align=True)
                    box.prop(ivy_modifier, '["Input_13"]', text = "Distance Min")
                    box.prop(ivy_modifier, '["Input_10"]', text = "Density")

                    box = layout.box()
                    box.label(text="Random")
                    box = box.column(align=True)
                    box.prop(ivy_modifier, '["Input_7"]', text = "Random Position")
                    box.prop(ivy_modifier, '["Input_14"]', text = "Emission Area")
                    box.prop(ivy_modifier, '["Input_11"]', text = "Surface Offset")
                    box.prop(ivy_modifier, '["Input_8"]', text = "Scale")
                    box.label(text="Ivy Random Position")
                    box = box.row(align=True)
                    box.prop(ivy_modifier, '["Input_12"]', text = "")
                    
                    box = layout.box()
                    box.label(text="Source info", icon = "INFO")
                    box.prop(ivy_modifier, '["Input_9"]', text = "Target")
                    box.prop(ivy_modifier, '["Input_16"]', text = "Ivy Asset")
                    box.prop(ivy_modifier, '["Input_17"]', text = "Ivy Emitter")

                elif type == "pointsnapinstance":
                    col.label(text="Modifier Properties :")
                    psi_modifier = obj.modifiers[modifiers[0]]
                    col = layout.column(align=True)
                    col.scale_y=2
                    col.operator("bagapie.pointsnapinstance", text= "Add Instances")
                    col = layout.column(align=True)
                    col.label(text="ESC to Stop")

                    col = layout.column(align=True)
                    box = layout.box()
                    box.label(text="Ivy")
                    box = box.column(align=True)
                    box.prop(psi_modifier, '["Input_9"]', text = "Offset Z")
                    box.prop(psi_modifier, '["Input_8"]', text = "Align Normal")
                    box = layout.box()
                    box.label(text="Random")
                    box = box.column(align=True)
                    box.prop(psi_modifier, '["Input_5"]', text = "Random Rotation")
                    box.prop(psi_modifier, '["Input_6"]', text = "Scale Min")
                    box.prop(psi_modifier, '["Input_7"]', text = "Scale Max")
                    
                    box = layout.box()
                    box.label(text="Source info", icon = "INFO")
                    box.prop(psi_modifier, '["Input_3"]', text = "Target")
                    box.prop(psi_modifier, '["Input_4"]', text = "Instances")

                elif type == "grass":
                    material_slots = obj.material_slots
                    index = 0
                    col.label(text="Grass Shader :")
                    for m in material_slots:
                        index += 1
                        material = m.material
                        nodes = material.node_tree.nodes
                        for node in nodes:
                            if node.label == modifiers[0]:
                                shader_node = node
                            elif node.label == modifiers[1]:
                                shader_node = node
                            elif node.label == modifiers[2]:
                                shader_node = node

                        if shader_node.label.startswith('BagaPie_Moss'):
                            box = layout.box()
                            box.label(text="Material " + str(index))
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[1], 'default_value', text = "Brightness")
                            box.prop(shader_node.inputs[0], 'default_value', text = "Saturation")

                        elif shader_node.label.startswith('BagaPie_LP_Plant'):
                            box = layout.box()
                            box.label(text="Material " + str(index))
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[0], 'default_value', text = "")
                            box.prop(shader_node.inputs[1], 'default_value', text = "AO White")
                            box.prop(shader_node.inputs[2], 'default_value', text = "AO Distance")
                            box.separator(factor = 0.5)
                            box.prop(shader_node.inputs[3], 'default_value', text = "Translucent")
                            box.prop(shader_node.inputs[4], 'default_value', text = "")
                            box.separator(factor = 0.5)
                            box.prop(shader_node.inputs[5], 'default_value', text = "Tint Intensity")
                            box.prop(shader_node.inputs[6], 'default_value', text = "Random Tint")
                            box.prop(shader_node.inputs[7], 'default_value', text = "")
                            box.separator(factor = 0.5)
                            box.prop(shader_node.inputs[8], 'default_value', text = "Brightness")
                            box.prop(shader_node.inputs[9], 'default_value', text = "Random Brightness")
                            box.prop(shader_node.inputs[10], 'default_value', text = "Saturation")
                            box.prop(shader_node.inputs[11], 'default_value', text = "Random Saturation")

                        else:
                            box = layout.box()
                            box.label(text="Material " + str(index))
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[1], 'default_value', text = "Brightness")
                            box.prop(shader_node.inputs[2], 'default_value', text = "Random Brightness")
                            box.prop(shader_node.inputs[3], 'default_value', text = "Saturation")
                            box.prop(shader_node.inputs[4], 'default_value', text = "Random Saturation")
                            box.separator(factor = 0.5)
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[5], 'default_value', text = "Season")
                            box.prop(shader_node.inputs[6], 'default_value', text = "Random Saison")
                            if shader_node.inputs[5].default_value + (shader_node.inputs[6].default_value) >= 0.9:
                                box.label(text="Season value up to 0.9", icon = 'ERROR')
                                box.label(text="This value add transparency.")
                                box.label(text="May increase render time !")
                                box.label(text="Decrease Season or Random Season")
                            box.separator(factor = 0.5)
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[7], 'default_value', text = "Translucent")
                            box.prop(shader_node.inputs[10], 'default_value', text = "Specular")
                            box.prop(shader_node.inputs[11], 'default_value', text = "Roughness")
              
                elif type == "plant":
                    material_slots = obj.material_slots
                    index = 0
                    col.label(text="Plant Shader :")
                    for m in material_slots:
                        index += 1
                        material = m.material
                        nodes = material.node_tree.nodes
                        disp = False
                        for node in nodes:
                            if node.label == modifiers[0]:
                                shader_node = node
                                disp = True
                            elif node.label == modifiers[1]:
                                shader_node = node
                            elif node.label == modifiers[2]:
                                shader_node = node

                        if shader_node.label == "BagaPie_LP_Plant":
                            box = layout.box()
                            box.label(text="Material " + str(index))
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[0], 'default_value', text = "Color")
                            box.prop(shader_node.inputs[1], 'default_value', text = "AO White")
                            box.prop(shader_node.inputs[2], 'default_value', text = "AO Distance")
                            if bpy.context.scene.render.engine == 'BLENDER_EEVEE':
                                if bpy.context.scene.eevee.use_gtao == False:
                                    box.prop(bpy.context.scene.eevee, 'use_gtao', text = "Use AO")
                            box.separator(factor = 1)
                            box.prop(shader_node.inputs[3], 'default_value', text = "Translucent")
                            box.prop(shader_node.inputs[4], 'default_value', text = "")
                            box.separator(factor = 1)
                            box.prop(shader_node.inputs[6], 'default_value', text = "Tint Intensity")
                            box.prop(shader_node.inputs[5], 'default_value', text = "Random Tint")
                            box.prop(shader_node.inputs[7], 'default_value', text = "")
                            box.separator(factor = 1)                            
                            box.prop(shader_node.inputs[8], 'default_value', text = "Brightness")
                            box.prop(shader_node.inputs[9], 'default_value', text = "Random Brightness")
                            box.prop(shader_node.inputs[10], 'default_value', text = "Saturation")
                            box.prop(shader_node.inputs[11], 'default_value', text = "Random Saturation")
                        
                        elif disp is True:
                            box = layout.box()
                            box.label(text="Material " + str(index))
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[1], 'default_value', text = "Brightness")
                            box.prop(shader_node.inputs[2], 'default_value', text = "Random Brightness")
                            box.prop(shader_node.inputs[3], 'default_value', text = "Saturation")
                            box.prop(shader_node.inputs[4], 'default_value', text = "Random Saturation")
                            box.separator(factor = 0.5)
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[5], 'default_value', text = "Season")
                            box.prop(shader_node.inputs[6], 'default_value', text = "Random Season")
                            if shader_node.inputs[5].default_value + (shader_node.inputs[6].default_value) >= 0.9:
                                box.label(text="Season value up to 0.9", icon = 'ERROR')
                                box.label(text="This value add transparency.")
                                box.label(text="May increase render time !")
                                box.label(text="Decrease Season or Random Season")
                            box.separator(factor = 0.5)
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[7], 'default_value', text = "Translucent")
                            box.prop(shader_node.inputs[10], 'default_value', text = "Specular")
                            box.prop(shader_node.inputs[11], 'default_value', text = "Roughness")
                    
                elif type == "rock":
                    material_slots = obj.material_slots
                    for m in material_slots:
                        material = m.material
                        nodes = material.node_tree.nodes
                        for node in nodes:
                            if node.label == modifiers[0]:
                                shader_node = node

                    col.label(text="Rock Shader :")
                    box = layout.box()
                    box.label(text= (m.name[:-4]).removeprefix('BagaPie_'))
                    box = box.column(align=True)
                    box.prop(shader_node.inputs[1], 'default_value', text = "Saturation")
                    box.prop(shader_node.inputs[2], 'default_value', text = "Random Saturation")
                    box.prop(shader_node.inputs[3], 'default_value', text = "Brightness")
                    box.prop(shader_node.inputs[4], 'default_value', text = "Random Brightness")
                    box.separator(factor = 0.5)
                    box.prop(shader_node.inputs[6], 'default_value', text = "Tint")
                    box.prop(shader_node.inputs[5], 'default_value', text = "")
                    box.separator(factor = 0.5)
                    box.prop(shader_node.inputs[7], 'default_value', text = "Specular")
                    box.prop(shader_node.inputs[8], 'default_value', text = "Roughness")

                    box.label(text="Bump")
                    box.prop(shader_node.inputs[12], 'default_value', text = "Threshold")
                    box.prop(shader_node.inputs[13], 'default_value', text = "Intensity")
                    box.label(text="Ambient Occlusion")
                    if bpy.context.scene.render.engine == 'BLENDER_EEVEE':
                        if bpy.context.scene.eevee.use_gtao == False:
                            box.label(text="AO disabled")
                            box.prop(bpy.context.scene.eevee, 'use_gtao', text = "Use AO")
                    box.prop(shader_node.inputs[14], 'default_value', text = "Intensity")
                    box.prop(shader_node.inputs[15], 'default_value', text = "Distance")
                    
                elif type == "tree":
                    material_slots = obj.material_slots
                    index = 0
                    col.label(text="Tree Shader :")
                    for m in material_slots:
                        index += 1
                        material = m.material
                        nodes = material.node_tree.nodes
                        disp = False
                        for node in nodes:
                            if node.label == modifiers[0]:
                                shader_node = node
                                disp = True
                            elif node.label == modifiers[1] and modifiers[1] != "":
                                shader_node = node
                                disp = True
                            elif node.label == modifiers[2] and modifiers[2] != "":
                                shader_node = node
                                disp = True

                        if disp is True:
                            if shader_node.label.startswith("BagaPie_LP_Tree_Leaf"):
                                box = layout.box()
                                box.label(text= (m.name[:-4]).removeprefix('BagaPie_'))
                                box = box.column(align=True)
                                box.prop(shader_node.inputs[0], 'default_value', text = "AO White")
                                box.prop(shader_node.inputs[1], 'default_value', text = "AO Distance")
                                box.separator(factor = 0.5)
                                box.prop(shader_node.inputs[2], 'default_value', text = "Subsurface")
                                box.prop(shader_node.inputs[3], 'default_value', text = "")
                                box.separator(factor = 0.5)
                                box.prop(shader_node.inputs[4], 'default_value', text = "Tint Intensity")
                                box.prop(shader_node.inputs[5], 'default_value', text = "Random Tint")
                                box.prop(shader_node.inputs[6], 'default_value', text = "")
                                box.separator(factor = 0.5)
                                box.prop(shader_node.inputs[7], 'default_value', text = "Brightness")
                                box.prop(shader_node.inputs[8], 'default_value', text = "Random Brightness")
                                box.prop(shader_node.inputs[9], 'default_value', text = "Saturation")
                                box.prop(shader_node.inputs[10], 'default_value', text = "Random Saturation")

                            elif shader_node.label.startswith("BagaPie_PL_Tree_Trunk"):
                                box = layout.box()
                                box.label(text= (m.name[:-4]).removeprefix('BagaPie_'))
                                box = box.column(align=True)
                                box.prop(shader_node.inputs[0], 'default_value', text = "AO White")
                                box.prop(shader_node.inputs[1], 'default_value', text = "AO Distance")
                                box.separator(factor = 0.5)
                                box.prop(shader_node.inputs[2], 'default_value', text = "Tint Intensity")
                                box.prop(shader_node.inputs[3], 'default_value', text = "")
                                box.separator(factor = 0.5)
                                box.prop(shader_node.inputs[5], 'default_value', text = "Brightness")
                                box.prop(shader_node.inputs[4], 'default_value', text = "Saturation")

                            else:
                                box = layout.box()
                                box.label(text= (m.name[:-4]).removeprefix('BagaPie_'))
                                box = box.column(align=True)
                                box.prop(shader_node.inputs[1], 'default_value', text = "Brightness")
                                box.prop(shader_node.inputs[2], 'default_value', text = "Random Brightness")
                                box.prop(shader_node.inputs[3], 'default_value', text = "Saturation")
                                box.prop(shader_node.inputs[4], 'default_value', text = "Random Saturation")
                                box.separator(factor = 0.5)
                                box = box.column(align=True)
                                box.prop(shader_node.inputs[5], 'default_value', text = "Season")
                                box.prop(shader_node.inputs[6], 'default_value', text = "Random Season")
                                if shader_node.inputs[5].default_value + (shader_node.inputs[6].default_value) >= 0.9:
                                    box.label(text="Season value up to 0.9", icon = 'ERROR')
                                    box.label(text="This value add transparency.")
                                    box.label(text="May increase render time !")
                                    box.label(text="Decrease Season or Random Season")
                                box.separator(factor = 0.5)
                                box = box.column(align=True)
                                box.prop(shader_node.inputs[7], 'default_value', text = "Translucent")
                                box.prop(shader_node.inputs[10], 'default_value', text = "Specular")
                                box.prop(shader_node.inputs[11], 'default_value', text = "Roughness")
                        
                elif type == "stump":
                    material_slots = obj.material_slots
                    for m in material_slots:
                        material = m.material
                        nodes = material.node_tree.nodes
                        for node in nodes:
                            if node.label == modifiers[0]:
                                shader_node = node

                    col.label(text="Stump Shader :")
                    box = layout.box()
                    box.label(text= (m.name[:-4]).removeprefix('BagaPie_'))
                    box = box.column(align=True)
                    box.prop(shader_node.inputs[1], 'default_value', text = "Saturation")
                    box.prop(shader_node.inputs[2], 'default_value', text = "Random Saturation")
                    box.prop(shader_node.inputs[3], 'default_value', text = "Brightness")
                    box.prop(shader_node.inputs[4], 'default_value', text = "Random Brightness")
                    box.separator(factor = 0.5)
                    box.prop(shader_node.inputs[6], 'default_value', text = "Tint")
                    box.prop(shader_node.inputs[5], 'default_value', text = "")
                    box.separator(factor = 0.5)
                    box.prop(shader_node.inputs[7], 'default_value', text = "Specular")
                    box.prop(shader_node.inputs[8], 'default_value', text = "Roughness")

                    box.label(text="Bump")
                    box.prop(shader_node.inputs[12], 'default_value', text = "Threshold")
                    box.prop(shader_node.inputs[13], 'default_value', text = "Intensity")
                    box.label(text="Ambient Occlusion")
                    box.prop(shader_node.inputs[14], 'default_value', text = "Intensity")
                    box.prop(shader_node.inputs[15], 'default_value', text = "Distance")

                elif type == "instancesdisplace":
                    col.label(text="Modifier Properties :")
                    psi_modifier = obj.modifiers[modifiers[0]]

                    col = layout.column(align=True)
                    box = layout.box()
                    box.label(text="Displace Instances")
                    box = box.column(align=True)
                    box.prop(psi_modifier, '["Input_3"]', text = "Scale")
                    box.prop(psi_modifier, '["Input_4"]', text = "Noise")
                    box = layout.box()
                    box.label(text="Orientation")
                    row = box.row(align=True)
                    row.prop(psi_modifier, '["Input_2"]', text = "")
                    box.label(text="Position")
                    row = box.row(align=True)
                    row.prop(psi_modifier, '["Input_5"]', text = "")

            elif prop is not None and obj is not None:
                
                box = layout.box()

                box.label(text="Duplicate : Alt + J")
                box.label(text="Duplicate Linked : Alt + N")

                col = layout.column()
                col.scale_y = 1.2

                col.operator("bagapie.deletegroup", text= "Delete Group")
                if obj["bagapie_child"][0].hide_select == True:
                    col.operator("bagapie.editgroup")
                else:
                    col.operator("bagapie.lockgroup")
                col.operator("bagapie.ungroup", text= "Ungroup")
                col.operator("bagapie.instance", text= "Instance")

                ################################################################ CHANGES <

            else:
                if bpy.context.object.mode == 'EDIT':
                    col = layout.column()
                    col.scale_y = 2.0
                    col.operator("bool.mode", text= "EXIT")

        # In case nothing is selected
        elif obj and obj.type not in obj_allowed_types:
            box = layout.box()
            box = box.column(align=True)
            row = box.row()
            row.label(text="Mesh or Curve Only")

        else:
            box = layout.box()
            box = box.column(align=True)
            row = box.row()
            row.label(text="No Object Selected")


class BAGAPIE_OP_modifierDisplay(Operator):
    """Hide modifier in viewport"""
    bl_idname = "hide.viewport"
    bl_label = "Hide Viewport"

    index: bpy.props.IntProperty(default=0)

    def execute(self, context):
        obj = context.object
        val = json.loads(obj.bagapieList[self.index]['val'])
        modifiers = val['modifiers']
        mo_type = val['name']
        avoid_string = "BagaPie_Texture"

        if mo_type == "scatter":
            scatter_modifier = obj.modifiers.get("BagaScatter")
            scatt_nde_group = scatter_modifier.node_group
            
            scatt_nde_visibility_op = scatt_nde_group.nodes["BagaPie_Scatter"].inputs[22].default_value

            if scatt_nde_visibility_op == True:
                scatt_nde_group.nodes["BagaPie_Scatter"].inputs[22].default_value = False
            else:
                scatt_nde_group.nodes["BagaPie_Scatter"].inputs[22].default_value = True

        elif mo_type == "pointeffector":
            scatter_modifier = obj.modifiers.get("BagaScatter")
            scatt_nde_group = scatter_modifier.node_group
            
            scatt_nde_visibility_op = scatt_nde_group.nodes[modifiers[1]].inputs[5].default_value

            if scatt_nde_visibility_op == True:
                scatt_nde_group.nodes[modifiers[1]].inputs[5].default_value = False
            else:
                scatt_nde_group.nodes[modifiers[1]].inputs[5].default_value = True

        elif mo_type == "scatterpaint":
            scatter_modifier = obj.modifiers.get("BagaScatter")
            scatt_nde_group = scatter_modifier.node_group
            
            scatt_nde_visibility_op = scatt_nde_group.nodes[modifiers[1]].inputs[12].default_value

            if scatt_nde_visibility_op == True:
                scatt_nde_group.nodes[modifiers[1]].inputs[12].default_value = False
            else:
                scatt_nde_group.nodes[modifiers[1]].inputs[12].default_value = True

        elif mo_type == "boolean":
            if obj.modifiers[modifiers[0]].show_viewport == True:
                for mo in modifiers:
                    if mo.startswith(("BagaBool","BagaBevel")) and not mo.startswith("BagaBevelObj"):
                        obj.modifiers[mo].show_viewport = False
                    else:
                        bool_obj = bpy.data.objects[modifiers[5]]
                        if mo != modifiers[5]:
                            if bool_obj.modifiers[mo].show_in_editmode == True and mo.startswith("BagaSolidify"):
                                bool_obj.modifiers[mo].show_viewport = False
                            elif not mo.startswith("BagaSolidify"):
                                bool_obj.modifiers[mo].show_viewport = False

            else:
                for mo in modifiers:
                    if mo.startswith(("BagaBool","BagaBevel")) and not mo.startswith("BagaBevelObj"):
                        obj.modifiers[mo].show_viewport = True
                    else:
                        bool_obj = bpy.data.objects[modifiers[5]]
                        if mo != modifiers[5]:
                            if bool_obj.modifiers[mo].show_in_editmode == True and mo.startswith("BagaSolidify"):
                                bool_obj.modifiers[mo].show_viewport = True
                            elif not mo.startswith("BagaSolidify"):
                                bool_obj.modifiers[mo].show_viewport = True

        elif mo_type == "window":

            if modifiers[6] == "win":
                wall = bpy.data.objects[modifiers[7]]
                if obj.modifiers[modifiers[0]].show_viewport == True:
                    for mo in modifiers:
                        if mo.startswith("Baga") and mo != modifiers[4] and mo != modifiers[5]:
                            obj.modifiers[mo].show_viewport = False
                        elif mo == modifiers[5]:
                            wall.modifiers[mo].show_viewport = False
                else:
                    for mo in modifiers:
                        if mo.startswith("Baga") and mo != modifiers[4] and mo != modifiers[5]:
                            obj.modifiers[mo].show_viewport = True
                        elif mo == modifiers[5]:
                            wall.modifiers[mo].show_viewport = True

            elif modifiers[6] == "wall":
                window = bpy.data.objects[modifiers[7]]
                if obj.modifiers[modifiers[0]].show_viewport == True:
                    for mo in modifiers:
                        if mo.startswith("Baga") and mo != modifiers[0] and mo != modifiers[5] and mo != modifiers[7]:
                            window.modifiers[mo].show_viewport = False
                        elif mo == modifiers[0] and mo != modifiers[7]:
                            obj.modifiers[mo].show_viewport = False
                else:
                    for mo in modifiers:
                        if mo.startswith("Baga") and mo != modifiers[0] and mo != modifiers[5] and mo != modifiers[7]:
                            window.modifiers[mo].show_viewport = True
                        elif mo == modifiers[0] and mo != modifiers[7]:
                            obj.modifiers[mo].show_viewport = True

        elif mo_type == "wallbrick":
            if obj.type=='MESH':
                mo = modifiers[0]
                if obj.modifiers[modifiers[0]].show_viewport == True:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_viewport = False
                else:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_viewport = True
            else:
                mo = modifiers[1]
                if obj.modifiers[modifiers[1]].show_viewport == True:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_viewport = False
                else:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_viewport = True

        elif mo_type == "ivy":
            if obj.modifiers[modifiers[0]].show_viewport == True:
                mo = modifiers[0]
                obj.modifiers[mo].show_viewport = False
            else:
                mo = modifiers[0]
                obj.modifiers[mo].show_viewport = True

        else:
            if obj.modifiers[modifiers[0]].show_viewport == True:
                for mo in modifiers:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_viewport = False
            else:
                for mo in modifiers:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_viewport = True

        return {'FINISHED'}


class BAGAPIE_OP_modifierDisplayRender(Operator):
    """Hide modifier in render"""
    bl_idname = "hide.render"
    bl_label = "Hide Render"

    index: bpy.props.IntProperty(default=0)

    def execute(self, context):
        obj = context.object
        val = json.loads(obj.bagapieList[self.index]['val'])
        modifiers = val['modifiers']
        mo_type = val['name']
        avoid_string = "BagaPie_Texture"

        if mo_type == "scatter":
            scatter_modifier = obj.modifiers.get("BagaScatter")
            scatt_nde_group = scatter_modifier.node_group
            
            scatt_nde_visibility_bool = scatt_nde_group.nodes["BagaPie_Scatter"].inputs[23].default_value

            if scatt_nde_visibility_bool == True:
                scatt_nde_group.nodes["BagaPie_Scatter"].inputs[23].default_value = False
            else:
                scatt_nde_group.nodes["BagaPie_Scatter"].inputs[23].default_value = True

        elif mo_type == "pointeffector":
            scatter_modifier = obj.modifiers.get("BagaScatter")
            scatt_nde_group = scatter_modifier.node_group
            
            scatt_nde_visibility_bool = scatt_nde_group.nodes[modifiers[1]].inputs[6].default_value

            if scatt_nde_visibility_bool == True:
                scatt_nde_group.nodes[modifiers[1]].inputs[6].default_value = False
            else:
                scatt_nde_group.nodes[modifiers[1]].inputs[6].default_value = True

        elif mo_type == "scatterpaint":
            scatter_modifier = obj.modifiers.get("BagaScatter")
            scatt_nde_group = scatter_modifier.node_group
            
            scatt_nde_visibility_bool = scatt_nde_group.nodes[modifiers[1]].inputs[13].default_value

            if scatt_nde_visibility_bool == True:
                scatt_nde_group.nodes[modifiers[1]].inputs[13].default_value = False
            else:
                scatt_nde_group.nodes[modifiers[1]].inputs[13].default_value = True

        elif mo_type == "boolean":
            if obj.modifiers[modifiers[0]].show_render == True:
                for mo in modifiers:
                    if mo.startswith(("BagaBool","BagaBevel")) and not mo.startswith("BagaBevelObj"):
                        obj.modifiers[mo].show_render = False
                    else:
                        bool_obj = bpy.data.objects[modifiers[5]]
                        if mo != modifiers[5]:
                            if bool_obj.modifiers[mo].show_in_editmode == True and mo.startswith("BagaSolidify"):
                                bool_obj.modifiers[mo].show_render = False
                            elif not mo.startswith("BagaSolidify"):
                                bool_obj.modifiers[mo].show_render = False

            else:
                for mo in modifiers:
                    if mo.startswith(("BagaBool","BagaBevel")) and not mo.startswith("BagaBevelObj"):
                        obj.modifiers[mo].show_render = True
                    else:
                        bool_obj = bpy.data.objects[modifiers[5]]
                        if mo != modifiers[5]:
                            if bool_obj.modifiers[mo].show_in_editmode == True and mo.startswith("BagaSolidify"):
                                bool_obj.modifiers[mo].show_render = True
                            elif not mo.startswith("BagaSolidify"):
                                bool_obj.modifiers[mo].show_render = True

        elif mo_type == "window":

            if modifiers[6] == "win":
                wall = bpy.data.objects[modifiers[7]]
                if obj.modifiers[modifiers[0]].show_render == True:
                    for mo in modifiers:
                        if mo.startswith("Baga") and mo != modifiers[4] and mo != modifiers[5]:
                            obj.modifiers[mo].show_render = False
                        elif mo == modifiers[5]:
                            wall.modifiers[mo].show_render = False
                else:
                    for mo in modifiers:
                        if mo.startswith("Baga") and mo != modifiers[4] and mo != modifiers[5]:
                            obj.modifiers[mo].show_render = True
                        elif mo == modifiers[5]:
                            wall.modifiers[mo].show_render = True

            elif modifiers[6] == "wall":
                window = bpy.data.objects[modifiers[7]]
                if obj.modifiers[modifiers[0]].show_render == True:
                    for mo in modifiers:
                        if mo.startswith("Baga") and mo != modifiers[0] and mo != modifiers[5] and mo != modifiers[7]:
                            window.modifiers[mo].show_render = False
                        elif mo == modifiers[0] and mo != modifiers[7]:
                            obj.modifiers[mo].show_render = False
                else:
                    for mo in modifiers:
                        if mo.startswith("Baga") and mo != modifiers[0] and mo != modifiers[5] and mo != modifiers[7]:
                            window.modifiers[mo].show_render = True
                        elif mo == modifiers[0] and mo != modifiers[7]:
                            obj.modifiers[mo].show_render = True

        elif mo_type == "wallbrick":
            if obj.type=='MESH':
                mo = modifiers[0]
                if obj.modifiers[modifiers[0]].show_render == True:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_render = False
                else:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_render = True
            else:
                mo = modifiers[1]
                if obj.modifiers[modifiers[1]].show_render == True:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_render = False
                else:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_render = True

        else:
            if obj.modifiers[modifiers[0]].show_render == True:
                for mo in modifiers:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_render = False
            else:
                for mo in modifiers:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_render = True

        return {'FINISHED'}


class BAGAPIE_OP_modifierApply(Operator):
    """Apply all related modifier"""
    bl_idname = "apply.modifier"
    bl_label = "apply.modifier"

    index: bpy.props.IntProperty(default=0)

    def execute(self, context):
        obj = context.object
        obj.select_set(True)
        val = json.loads(obj.bagapieList[self.index]['val'])
        modifiers = val['modifiers']
        avoid_string = "BagaPie_Texture"
        mo_type = val['name']

        if mo_type == "window":
            obj.data = obj.data.copy()
        
        for mo in modifiers:
            if mo.startswith("Baga") and mo.startswith(avoid_string) == False:
                if mo_type == 'wallbrick':
                    bpy.ops.object.convert(target='MESH')
                if mo_type == 'array':
                    mo_name = obj.modifiers[mo].node_group.name

                    if "Line" in mo_name:
                        obj.modifiers[mo]["Input_10"] = 1
                    elif "Grid" in mo_name:
                        obj.modifiers[mo]["Input_14"] = 1
                    elif "Circle" in mo_name:
                        obj.modifiers[mo]["Input_21"] = 1
                    elif "Curve" in mo_name:
                        obj.modifiers[mo]["Input_13"] = 1

                    bpy.ops.object.convert(target='MESH')

                else:
                    try:
                        bpy.ops.object.modifier_apply(modifier=mo)
                    except:
                        bpy.ops.object.modifier_remove(modifier=mo)

        if mo_type == "boolean":
            bool_obj = bpy.data.objects[modifiers[5]]
            bpy.data.objects.remove(bool_obj)

        elif mo_type == "window":

            if modifiers[6] == "win":
                win_bool = bpy.data.objects[modifiers[4]]
                wall = bpy.data.objects[modifiers[7]]
                # applique le modifier sur le mur
                bpy.context.view_layer.objects.active = wall
                try:
                    bpy.ops.object.modifier_apply(modifier=modifiers[5])
                except:
                    bpy.ops.object.modifier_remove(modifier=modifiers[5])
                bpy.data.objects.remove(win_bool)
                # relève le modifier de la liste
                index = 0
                for i in range(len(wall.bagapieList)):
                    index = index + i
                    val = json.loads(wall.bagapieList[index]['val'])
                    modifiers = val['modifiers']
                    mo_type = val['name']
                    if mo_type == "window":
                        wall.bagapieList.remove(index)
                        index -=1
                        wall.bagapieIndex = wall.bagapieIndex -1
                bpy.context.view_layer.objects.active = obj

            elif modifiers[6] == "wall":
                win_bool = bpy.data.objects[modifiers[5]]
                bpy.data.objects.remove(win_bool)
                win = bpy.data.objects[modifiers[7]]

                for mo in win.modifiers:
                    m = mo.name
                    if m.startswith("Baga"):
                        bpy.context.view_layer.objects.active = win
                        try:
                            bpy.ops.object.modifier_apply(modifier=m)
                        except:
                            bpy.ops.object.modifier_remove(modifier=m)
                index = 0
                for i in range(len(win.bagapieList)):
                    index = index + i
                    val = json.loads(win.bagapieList[index]['val'])
                    modifiers = val['modifiers']
                    mo_type = val['name']
                    if mo_type == "window":
                        win.bagapieList.remove(index)
                        index -=1
                obj.bagapieIndex = obj.bagapieIndex -1
                bpy.context.view_layer.objects.active = obj

        obj.bagapieList.remove(self.index)

        return {'FINISHED'}
